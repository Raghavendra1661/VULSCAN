const form = document.getElementById("form");
const out = document.getElementById("out");
const errBox = document.getElementById("err");
const goBtn = document.getElementById("go");
const portSel = document.getElementById("ports");
const custom = document.getElementById("custom");
let lastData = null;

portSel.addEventListener("change", () => {
  custom.classList.toggle("hidden", portSel.value !== "custom");
});

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined) e.textContent = text;
  return e;
}

form.addEventListener("submit", async (ev) => {
  ev.preventDefault();
  errBox.textContent = "";
  goBtn.disabled = true;
  goBtn.textContent = "Scanning...";

  const body = {
    target: document.getElementById("target").value,
    ports: portSel.value === "custom" ? custom.value : portSel.value,
    consent: document.getElementById("consent").checked,
    options: {
      versions: document.getElementById("o-versions").checked,
      web: document.getElementById("o-web").checked,
      tls: document.getElementById("o-tls").checked,
    },
  };

  try {
    const res = await fetch("/api/scan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Scan failed");
    lastData = data;
    render(data);
  } catch (e) {
    errBox.textContent = e.message;
  } finally {
    goBtn.disabled = false;
    goBtn.textContent = "Start scan";
  }
});

function render(d) {
  out.replaceChildren();

  const stats = el("div", "stats");
  for (const sev of ["critical", "high", "medium", "low"]) {
    const s = el("div", "stat s-" + sev);
    s.append(el("span", "", sev[0].toUpperCase() + sev.slice(1)), el("b", "", d.counts[sev]));
    stats.append(s);
  }
  out.append(stats);

  const meta = el("div", "meta");
  [["Target", d.target], ["Ports checked", d.scanned], ["Open", d.open_ports.length],
   ["Time", d.seconds + "s"], ["Finished", d.time]].forEach(([k, v]) => {
    const s = el("span", "", k + ": ");
    s.append(el("b", "", v));
    meta.append(s);
  });
  out.append(meta);

  const actions = el("div", "actions");
  const rep = el("a", "btn", "Open HTML report");
  rep.href = "/report"; rep.target = "_blank";
  const js = el("button", "btn", "Download JSON");
  js.type = "button";
  js.onclick = () => {
    const blob = new Blob([JSON.stringify(lastData, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "scan-" + d.target + ".json";
    a.click();
  };
  actions.append(rep, js);
  out.append(actions);

  const fCard = el("div", "card");
  fCard.append(el("h2", "", "Findings (" + d.findings.length + ")"));
  if (!d.findings.length) {
    fCard.append(el("p", "", "Nothing found with the selected checks."));
  }
  d.findings.forEach((f) => {
    const box = el("div", "finding s-" + f.severity);
    const top = el("div", "top");
    top.append(el("span", "pill", f.severity), el("h4", "", f.title), el("span", "port", "port " + f.port));
    box.append(top, el("p", "", f.detail), el("p", "fix", "Fix: " + f.fix));
    fCard.append(box);
  });
  out.append(fCard);

  const pCard = el("div", "card section");
  pCard.append(el("h2", "", "Open ports"));
  if (!d.open_ports.length) {
    pCard.append(el("p", "", "No open ports found in the range."));
  } else {
    const t = el("table");
    const head = el("tr");
    ["Port", "Service", "Software", "Banner"].forEach((h) => head.append(el("th", "", h)));
    t.append(head);
    d.open_ports.forEach((p) => {
      const r = el("tr");
      r.append(el("td", "mono", p.port), el("td", "", p.service),
               el("td", "", p.software || "-"),
               el("td", "", (p.banner || "").split("\n")[0].slice(0, 60) || "-"));
      t.append(r);
    });
    pCard.append(t);
  }
  out.append(pCard);
}
