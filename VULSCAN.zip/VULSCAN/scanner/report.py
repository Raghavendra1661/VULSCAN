"""Build the summary displayed on the VulnScan report page."""

from datetime import datetime


SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}


def summarize(target, open_ports, findings, elapsed_seconds, ports_checked):
    findings = sorted(
        findings,
        key=lambda finding: (
            SEVERITY_ORDER.get(finding.get("severity"), 99),
            finding.get("port", 0),
        ),
    )

    totals = {severity: 0 for severity in SEVERITY_ORDER}
    for finding in findings:
        severity = finding.get("severity")
        if severity in totals:
            totals[severity] += 1

    return {
        "target": target,
        "time": datetime.now().strftime("%d %b %Y, %H:%M"),
        "seconds": round(elapsed_seconds, 1),
        "scanned": ports_checked,
        "open_ports": open_ports,
        "findings": findings,
        "counts": totals,
    }
