import json
import os
import re

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

with open(os.path.join(HERE, "data", "min_versions.json")) as f:
    MIN_VERSIONS = json.load(f)

# versions with a well known serious problem
KNOWN_BAD = {
    ("vsftpd", "2.3.4"): "this release shipped with a backdoor (CVE-2011-2523)",
}

PATTERN = re.compile(
    r"(apache|nginx|openssh|vsftpd|proftpd|microsoft-iis)[/_ ]v?(\d+(?:\.\d+)*)",
    re.I)


def to_tuple(v):
    return tuple(int(x) for x in v.split("."))


def detect(banner):
    m = PATTERN.search(banner or "")
    if not m:
        return None
    name = m.group(1).lower()
    if name == "microsoft-iis":
        name = "iis"
    return name, m.group(2)


def check_versions(open_ports):
    findings = []
    for p in open_ports:
        found = detect(p["banner"])
        if not found:
            continue
        name, ver = found
        p["software"] = f"{name} {ver}"
        if (name, ver) in KNOWN_BAD:
            findings.append({
                "severity": "critical", "port": p["port"],
                "title": f"{name} {ver} has a known backdoor",
                "detail": f"Banner reports {name} {ver}: {KNOWN_BAD[(name, ver)]}.",
                "fix": "Replace it with a current release right away."})
            continue
        minimum = MIN_VERSIONS.get(name)
        if minimum and to_tuple(ver) < to_tuple(minimum):
            findings.append({
                "severity": "high", "port": p["port"],
                "title": f"Outdated {name} ({ver})",
                "detail": f"Version {ver} is older than {minimum}, the oldest release this tool treats as supported.",
                "fix": f"Upgrade {name} to {minimum} or newer and check its security advisories."})
    return findings
