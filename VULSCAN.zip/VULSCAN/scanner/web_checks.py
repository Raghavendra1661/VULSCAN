import http.client
import socket
import ssl
import time

WEB_PORTS = {80: False, 8000: False, 8080: False, 8888: False,
             443: True, 8443: True}

HEADERS = {
    "content-security-policy": ("medium", "Missing Content-Security-Policy",
        "Without a CSP the browser will run injected scripts.",
        "Add a Content-Security-Policy header that limits script sources."),
    "x-frame-options": ("medium", "Missing X-Frame-Options",
        "The page can be embedded in another site, which allows clickjacking.",
        "Send X-Frame-Options: DENY (or use CSP frame-ancestors)."),
    "x-content-type-options": ("low", "Missing X-Content-Type-Options",
        "Browsers may guess content types and run uploads as scripts.",
        "Send X-Content-Type-Options: nosniff."),
    "referrer-policy": ("low", "Missing Referrer-Policy",
        "Full URLs may leak to other sites through the Referer header.",
        "Send Referrer-Policy: strict-origin-when-cross-origin."),
}


def _fetch(host, port, secure):
    if secure:
        ctx = ssl._create_unverified_context()
        conn = http.client.HTTPSConnection(host, port, timeout=4, context=ctx)
    else:
        conn = http.client.HTTPConnection(host, port, timeout=4)
    try:
        conn.request("GET", "/", headers={"User-Agent": "VulnScan-student-project"})
        resp = conn.getresponse()
        return resp.status, resp.getheaders()
    finally:
        conn.close()


def check_web(host, open_ports):
    findings = []
    open_nums = {p["port"] for p in open_ports}
    for p in open_ports:
        port = p["port"]
        if port not in WEB_PORTS:
            continue
        secure = WEB_PORTS[port]
        try:
            status, hdrs = _fetch(host, port, secure)
        except (OSError, http.client.HTTPException):
            continue
        h = {k.lower(): v for k, v in hdrs}

        for name, (sev, title, why, fix) in HEADERS.items():
            if name not in h:
                findings.append({"severity": sev, "port": port, "title": title,
                                 "detail": why, "fix": fix})
        if secure and "strict-transport-security" not in h:
            findings.append({"severity": "medium", "port": port,
                "title": "Missing Strict-Transport-Security",
                "detail": "Browsers are not told to stay on HTTPS.",
                "fix": "Send Strict-Transport-Security: max-age=31536000."})

        server = h.get("server", "")
        if any(c.isdigit() for c in server):
            p["software"] = p.get("software") or server
            findings.append({"severity": "low", "port": port,
                "title": "Server banner reveals version",
                "detail": f"The Server header says '{server}', which helps attackers pick exploits.",
                "fix": "Hide the version (ServerTokens Prod in Apache, server_tokens off in nginx)."})
        if "x-powered-by" in h:
            findings.append({"severity": "low", "port": port,
                "title": "X-Powered-By header present",
                "detail": f"The header exposes '{h['x-powered-by']}'.",
                "fix": "Remove the X-Powered-By header."})

        cookies = [v for k, v in hdrs if k.lower() == "set-cookie"]
        for c in cookies:
            lc = c.lower()
            name = c.split("=")[0]
            if "httponly" not in lc:
                findings.append({"severity": "medium", "port": port,
                    "title": f"Cookie '{name}' lacks HttpOnly",
                    "detail": "JavaScript can read this cookie, so XSS can steal it.",
                    "fix": "Set the HttpOnly flag on session cookies."})
            if secure and "secure" not in lc:
                findings.append({"severity": "medium", "port": port,
                    "title": f"Cookie '{name}' lacks Secure",
                    "detail": "The cookie can be sent over plain HTTP.",
                    "fix": "Set the Secure flag."})

        if not secure and not ({443, 8443} & open_nums):
            findings.append({"severity": "medium", "port": port,
                "title": "Site served over plain HTTP only",
                "detail": "Traffic can be read or changed on the network.",
                "fix": "Install a certificate and redirect HTTP to HTTPS."})
    return findings


def check_tls(host, open_ports):
    findings = []
    for p in open_ports:
        if p["port"] not in (443, 8443):
            continue
        port = p["port"]
        try:
            ctx = ssl.create_default_context()
            with socket.create_connection((host, port), timeout=4) as raw:
                with ctx.wrap_socket(raw, server_hostname=host) as s:
                    cert = s.getpeercert()
                    version = s.version()
            left = (ssl.cert_time_to_seconds(cert["notAfter"]) - time.time()) / 86400
            if left < 0:
                findings.append({"severity": "high", "port": port,
                    "title": "TLS certificate expired",
                    "detail": f"The certificate expired {int(-left)} days ago.",
                    "fix": "Renew the certificate."})
            elif left < 20:
                findings.append({"severity": "low", "port": port,
                    "title": "TLS certificate expires soon",
                    "detail": f"Only {int(left)} days left.",
                    "fix": "Renew the certificate or enable auto-renewal."})
            if version in ("TLSv1", "TLSv1.1"):
                findings.append({"severity": "high", "port": port,
                    "title": f"Old protocol {version} accepted",
                    "detail": "TLS 1.0 and 1.1 are deprecated.",
                    "fix": "Allow only TLS 1.2 and 1.3."})
        except ssl.SSLCertVerificationError as e:
            findings.append({"severity": "medium", "port": port,
                "title": "TLS certificate not trusted",
                "detail": f"Verification failed: {e.verify_message}.",
                "fix": "Use a certificate from a trusted authority that matches the hostname."})
        except (OSError, ssl.SSLError):
            continue
    return findings
