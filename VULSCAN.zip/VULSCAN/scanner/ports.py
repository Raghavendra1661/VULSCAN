"""Small TCP port scanner used by the VulnScan lab project."""

import socket
from concurrent.futures import ThreadPoolExecutor


COMMON_PORTS = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
    80: "HTTP", 110: "POP3", 111: "RPC", 135: "MSRPC",
    139: "NetBIOS", 143: "IMAP", 443: "HTTPS", 445: "SMB",
    993: "IMAPS", 995: "POP3S", 1433: "MSSQL", 3306: "MySQL",
    3389: "RDP", 5432: "PostgreSQL", 5900: "VNC", 6379: "Redis",
    8000: "HTTP-Alt", 8080: "HTTP-Proxy", 8443: "HTTPS-Alt",
    8888: "HTTP-Alt", 9200: "Elasticsearch", 27017: "MongoDB",
}

HTTP_PORTS = {80, 8000, 8080, 8888}

# These services deserve attention when they are reachable from a network.
# A finding is only a warning; it does not prove that the service is vulnerable.
RISKY_SERVICES = {
    21: ("high", "FTP traffic may be unencrypted.", "Use SFTP or FTPS and disable anonymous access."),
    23: ("critical", "Telnet sends login details without encryption.", "Disable Telnet and use SSH."),
    111: ("medium", "rpcbind can reveal information about RPC services.", "Disable it if the system does not need it."),
    135: ("medium", "Windows RPC should not normally be exposed publicly.", "Restrict it with the host firewall."),
    139: ("medium", "NetBIOS can reveal information about the host.", "Disable NetBIOS when it is not required."),
    445: ("high", "Exposed SMB can be targeted in ransomware attacks.", "Allow SMB only on trusted networks."),
    1433: ("medium", "A database service is reachable over the network.", "Allow access only from application servers."),
    3306: ("medium", "A database service is reachable over the network.", "Allow access only from application servers."),
    3389: ("high", "RDP is often targeted by password attacks.", "Place RDP behind a VPN and use strong authentication."),
    5432: ("medium", "A database service is reachable over the network.", "Allow access only from application servers."),
    5900: ("high", "VNC may be exposed with weak access controls.", "Restrict VNC or tunnel it through SSH."),
    6379: ("high", "Redis may be exposed without suitable access controls.", "Bind Redis to trusted interfaces and require authentication."),
    9200: ("high", "Elasticsearch may expose data if access is unrestricted.", "Enable its security features and restrict network access."),
    27017: ("high", "MongoDB should not be open to untrusted networks.", "Enable authentication and restrict the listening interface."),
}


def parse_range(value):
    """Convert input such as '22,80,8000-8010' into a sorted port list."""
    value = (value or "common").strip().lower()
    if value == "common":
        return sorted(COMMON_PORTS)

    ports = set()
    entries = value.split(",")
    if any(not entry.strip() for entry in entries):
        raise ValueError("Remove empty entries from the port list.")

    for entry in entries:
        entry = entry.strip()
        if "-" in entry:
            pieces = entry.split("-")
            if len(pieces) != 2:
                raise ValueError(f"Invalid port range: {entry}")
            try:
                start, end = (int(piece.strip()) for piece in pieces)
            except ValueError as exc:
                raise ValueError(f"Invalid port range: {entry}") from exc
            if start > end:
                raise ValueError("The first port in a range must be smaller.")
            if start < 1 or end > 65535:
                raise ValueError("Ports must be between 1 and 65535.")
            ports.update(range(start, end + 1))
        else:
            try:
                port = int(entry)
            except ValueError as exc:
                raise ValueError(f"Invalid port: {entry}") from exc
            if not 1 <= port <= 65535:
                raise ValueError("Ports must be between 1 and 65535.")
            ports.add(port)

        if len(ports) > 5000:
            raise ValueError("Please scan no more than 5000 ports at a time.")

    if not ports:
        raise ValueError("Enter at least one port to scan.")
    return sorted(ports)


def _read_banner(connection, port):
    """Try to read a short service response after connecting."""
    try:
        if port in HTTP_PORTS:
            connection.sendall(b"HEAD / HTTP/1.0\r\nHost: localhost\r\n\r\n")
        return connection.recv(1024).decode("utf-8", errors="replace").strip()[:400]
    except OSError:
        return ""


def _check_one_port(target, port, timeout):
    try:
        with socket.create_connection((target, port), timeout=timeout) as connection:
            connection.settimeout(1.5)
            banner = _read_banner(connection, port)
        return {
            "port": port,
            "service": COMMON_PORTS.get(port, "unknown"),
            "banner": banner,
        }
    except OSError:
        return None


def scan_ports(target, ports, timeout=0.8, workers=100):
    """Return details for TCP ports that accept a connection."""
    jobs = [(target, port, timeout) for port in ports]
    with ThreadPoolExecutor(max_workers=workers) as executor:
        results = executor.map(lambda job: _check_one_port(*job), jobs)
    return sorted((item for item in results if item), key=lambda item: item["port"])


def risky_service_findings(open_ports):
    findings = []
    for item in open_ports:
        port = item["port"]
        if port not in RISKY_SERVICES:
            continue
        severity, reason, recommendation = RISKY_SERVICES[port]
        findings.append({
            "severity": severity,
            "port": port,
            "title": f"{item['service']} is exposed",
            "detail": reason,
            "fix": recommendation,
        })
    return findings
