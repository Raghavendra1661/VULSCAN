"""Tests for the data prepared for the HTML scan report."""

import unittest

from scanner.report import summarize


class ReportTests(unittest.TestCase):
    def test_findings_are_sorted_by_severity(self):
        findings = [
            {"severity": "low", "port": 80},
            {"severity": "critical", "port": 23},
            {"severity": "high", "port": 445},
        ]
        result = summarize("127.0.0.1", [], findings, 1.26, 10)
        self.assertEqual(
            [item["severity"] for item in result["findings"]],
            ["critical", "high", "low"],
        )

    def test_counts_include_all_severity_levels(self):
        result = summarize(
            "localhost", [], [{"severity": "medium", "port": 80}], 0.5, 3
        )
        self.assertEqual(
            result["counts"],
            {"critical": 0, "high": 0, "medium": 1, "low": 0},
        )

    def test_elapsed_time_is_rounded(self):
        result = summarize("localhost", [], [], 1.26, 3)
        self.assertEqual(result["seconds"], 1.3)


if __name__ == "__main__":
    unittest.main()
