"""Tests for the port input and service-warning logic."""

import unittest

from scanner.ports import parse_range, risky_service_findings


class PortInputTests(unittest.TestCase):
    def test_common_ports_are_sorted_and_unique(self):
        result = parse_range("common")
        self.assertEqual(result, sorted(set(result)))
        self.assertIn(80, result)
        self.assertIn(443, result)

    def test_range_and_single_ports_can_be_mixed(self):
        self.assertEqual(parse_range("80, 20-22, 80"), [20, 21, 22, 80])

    def test_reversed_range_is_not_accepted(self):
        with self.assertRaises(ValueError):
            parse_range("90-80")

    def test_port_must_be_in_valid_tcp_range(self):
        with self.assertRaises(ValueError):
            parse_range("70000")

    def test_empty_entries_are_rejected(self):
        with self.assertRaises(ValueError):
            parse_range("80,,443")

    def test_invalid_text_is_rejected(self):
        with self.assertRaises(ValueError):
            parse_range("http")

    def test_telnet_gets_critical_warning(self):
        findings = risky_service_findings([
            {"port": 23, "service": "Telnet"}
        ])
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0]["severity"], "critical")

    def test_unlisted_service_does_not_create_warning(self):
        self.assertEqual(
            risky_service_findings([{"port": 8081, "service": "unknown"}]),
            [],
        )


if __name__ == "__main__":
    unittest.main()
