"""Checks for the small service-version reference used by VulnScan."""

import unittest

from scanner.versions import check_versions, detect, to_tuple


class VersionCheckTests(unittest.TestCase):
    def test_detects_apache_banner(self):
        self.assertEqual(detect("Apache/2.4.10 (Unix)"), ("apache", "2.4.10"))

    def test_normalises_iis_name(self):
        self.assertEqual(detect("Microsoft-IIS/8.5"), ("iis", "8.5"))

    def test_ignores_banner_without_supported_version(self):
        self.assertIsNone(detect("Unknown web server"))

    def test_version_parts_are_numeric(self):
        self.assertEqual(to_tuple("2.4.10"), (2, 4, 10))

    def test_known_bad_version_creates_critical_finding(self):
        results = check_versions([{"port": 21, "banner": "vsftpd 2.3.4"}])
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["severity"], "critical")

    def test_missing_banner_is_skipped(self):
        self.assertEqual(check_versions([{"port": 80, "banner": ""}]), [])


if __name__ == "__main__":
    unittest.main()
